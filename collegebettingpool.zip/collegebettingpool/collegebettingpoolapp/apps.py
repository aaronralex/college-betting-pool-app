from django.apps import AppConfig


class CollegebettingpoolappConfig(AppConfig):
    name = 'collegebettingpoolapp'
